# mock 150 questions ready version 1

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Kunhutty/pen/01a0c41a-f5d7-7e3b-9523-45a0edd323bb](https://codepen.io/editor/Kunhutty/pen/01a0c41a-f5d7-7e3b-9523-45a0edd323bb).

